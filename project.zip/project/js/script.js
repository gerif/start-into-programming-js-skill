let buttonDarkTheme = document.querySelector('.theme-button-dark');
let buttonLightTheme = document.querySelector('.theme-button-light');
let buttonSerif = document.querySelector('.font-button-serif');
let buttonSansSerif = document.querySelector('.font-button-sans-serif');
let blogArticle = document.querySelectorAll('.blog-article');
let buttonGrid = document.querySelector('.card-view-button-grid');
let buttonList = document.querySelector('.card-view-button-list');
let cards = document.querySelector('.cards');
let activeImage = document.querySelector('.active-photo');
let cardsImage = document.querySelectorAll('.preview-list li a');
let currentActiveImage = document.querySelector('.active-item');



/*theme changer */
buttonDarkTheme.onclick = function () {
	// body...
	document.body.classList.add('dark');
	buttonDarkTheme.classList.add('active');
	buttonLightTheme.classList.remove('active');
}

buttonLightTheme.onclick = function () {
	// body...
	document.body.classList.remove('dark');
	buttonDarkTheme.classList.remove('active');
	buttonLightTheme.classList.add('active');
}

/*font changer */
buttonSerif.onclick = function () {
	// body...
	document.body.classList.add('serif');
	buttonSerif.classList.add('active');
	buttonSansSerif.classList.remove('active');
}


buttonSansSerif.onclick = function () {
	// body...
	document.body.classList.remove('serif');
	buttonSansSerif.classList.add('active');
	buttonSerif.classList.remove('active');
}
/* show more button*/
/*for(let el of blogArticle){
	let btn = el.querySelectorAll('.more');
	for(let elo of btn ){
		elo.onclick = function(){
	el.classList.remove('short');
		}
	}
	
}*/


for(let el of blogArticle){
	let btn = el.querySelector('.more');
	btn.onclick = function(){
		el.classList.remove('short');
	}
}

/* rent*/
buttonList.onclick = function(){
	buttonList.classList.add('active');
	buttonGrid.classList.remove('active');
	cards.classList.add('list');

}

buttonGrid.onclick = function(){
	buttonGrid.classList.add('active');
	buttonList.classList.remove('active');
	cards.classList.remove('list');

}

/*gallery*/

/*activeImage.onclick = function(){
  alert(1)
}*/

for(let el of cardsImage){
	el.onclick = function(evt){
		evt.preventDefault();
		let currentActiveImg = currentActiveImage;
  		currentActiveImg.classList.remove('active-item');
  		el.classList.add('active-item');
  		activeImage.src = el.href;
  		currentActiveImage = el;

	}
}






